# Term project for TTK4155 -- Group 10

This is group 10's term project in TTK4155 - Embedded and Industrial Computer System Design. 
