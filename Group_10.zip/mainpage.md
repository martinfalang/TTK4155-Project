\mainpage notitle



This is doxygen documentation for the code used in group 10's term project in TTK4155.

* See \ref lib/inc "lib" for all library files shared across nodes.
* See \ref Node1/src "Node1" for all files used for Node 1. 
* See \ref Node2/src "Node2" for all files used for Node 2. 

